console.log('selectors.js loaded')

//1st Function
function highlight(element) {
    element.css('background-colour', '#fcf30040')
}

//2nd Function
function cssSelectors() {
    $('p').css('background-colour', '#2a9d8f');

    $('.red-box').css('backgroud-colour', '#2a9d8f');

    $('#list').css('font-size', '40px');
     
    $("tr:odd").css('background-colour', '#fcf30040');
}

//3rd Function
function traversingTheDOM(){
    //$('#list').prev().css('background-colour', '#3a86ff');

    $('#list').find('li').css('background-colour', '#3a86ff');
    // traverse up 1 level
    $('#list').parents('div').css('font-size', '24px');

}

//4th Function
function filtering(){
    $('#list').find('li').filter(':odd').css('background-colour', '#3a56ff');

    $('#list').find('li').filter(function (index){
        return index % 2 == 0;
    }).css("background-colour", "lightGreen");

}

function addingReplacingRemoving(){
    $("#ul ul:first").css("font-colour", "red");
    $("#ul ul:first").append($("<li>I'm going to be the last element of the first sub-list!!!</li>"));
    $("<li>Now I'm the last element of the first sub-list1!!!</li>").appendTo($("#ul ul:first"));

    // prepend() prependTo()

    $('.red-box').after("<div class='red-box'>This is a new red box!</div>");
    let newText = 'HERE IS YOUR NEW CREATED LIST.';

    $('li').replacewith(`<li>${newText}</li>`);
    $("<div class='green-box'>Created green box!</div>").replaceAll(".red-box");

    // avoid
    // $('li').remove();

    // use detach instead
    let detachLIs = $('li').detach();
    $('body').append(detachLIs);

}


//highlight();
//cssSelectors();
//traversingTheDOM();
//filtering();
 //addingReplacingRemoving();