// ALL ABOUT ARRAYS

let a = [1, 2, 3, 4, 5]

// array using contructor
let j = new Array();
console.log(`Empty array: ${j}`);
j.push(34);
console.log(`NOT Empty array: ${j}`);

// contructor with values
let k = new Array(110, 20, 30);
console.log(`3-value array: ${k}`);

//
let m = new Array(10);
console.log(`New array?? ${m}`);
m.push(88);
console.log('New aaray now?: ${m}');
m[0] = 20;
console.log(`Replaced element ${m}`);

//
let p = new Array(10).fill("Friday!");
console.log(`Really happy it's ${p}`);

function sqaure(x) {
return x*x;
}

let r = new Array(1, 33, 22, 5);
let newR = r.map(function (value){
    // 
    return sqaure(value);
})
console.log(`New array ${newR}`);